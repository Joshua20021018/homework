//
//  ProfileViewViewModel.swift
//  studentDoList
//
//  Created by Joshua on 30/1/2024.
//
import FirebaseAuth
import FirebaseFirestore
import Foundation

class ProfileViewViewModel: ObservableObject {
    init() {}
    
    
    }
    func logOut() {
        
    }

